/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
// Структура для хранения статуса
typedef struct {
    uint8_t rssi;       // Число от 0 до 31
    char operator[17];  // Имя оператора (строка)
    char time[22]; 		// current time
} GSM_NetStatus;

typedef struct {
    const char *pattern;       // Что ищем в сыром ответе (подстрока)
    const char *friendly_name; // Что красиво выводим на OLED
} OperatorLookup;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define PWX_Pin GPIO_PIN_0
#define PWX_GPIO_Port GPIOA
#define DTR_Pin GPIO_PIN_4
#define DTR_GPIO_Port GPIOA
#define Col0_Pin GPIO_PIN_6
#define Col0_GPIO_Port GPIOA
#define Col1_Pin GPIO_PIN_7
#define Col1_GPIO_Port GPIOA
#define Col2_Pin GPIO_PIN_8
#define Col2_GPIO_Port GPIOA
#define Row0_Pin GPIO_PIN_9
#define Row0_GPIO_Port GPIOA
#define Row1_Pin GPIO_PIN_10
#define Row1_GPIO_Port GPIOA
#define Row2_Pin GPIO_PIN_11
#define Row2_GPIO_Port GPIOA
#define Row3_Pin GPIO_PIN_12
#define Row3_GPIO_Port GPIOA

/* USER CODE BEGIN Private defines */
void GSM_UpdateNetStatus(void);
void KeyboardOn(void);
uint8_t GetKey(void);
void RunCall(void);
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
