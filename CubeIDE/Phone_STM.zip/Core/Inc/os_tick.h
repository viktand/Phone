#ifndef OS_TICK_H
#define OS_TICK_H

#include "stdint.h"

#ifdef  __cplusplus
extern "C" {
#endif

// Инициализация системного таймера
int32_t OS_Tick_Setup (uint32_t freq, uint32_t irq);

// Остановка системного таймера
void OS_Tick_Disable (void);

// Установка следующего срабатывания
void OS_Tick_Restart (uint32_t ticks);

// Получение текущего значения счетчика
uint32_t OS_Tick_GetCount (void);

// Получение частоты таймера
uint32_t OS_Tick_GetInterval (void);

// Функция обработки прерывания (вызывается из SysTick_Handler)
void OS_Tick_Handler (void);

#ifdef  __cplusplus
}
#endif

#endif
