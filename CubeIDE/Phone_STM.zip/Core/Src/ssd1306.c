/*
 * ssd1306.c
 *
 *  Created on: 9 сент. 2026 г.
 *      Author: vikta
 */
#include "ssd1306.h"
#include <string.h>

//static uint8_t buffer[SSD1306_WIDTH * SSD1306_HEIGHT / 8];

static uint8_t cursor_x = 0;
static uint8_t cursor_page = 0;

// Отправка команды в дисплей
static void SSD1306_WriteCmd(uint8_t cmd) {
    uint8_t data[2] = {0x00, cmd}; // 0x00 - Control Byte для команды
    HAL_I2C_Master_Transmit(&hi2c1, SSD1306_I2C_ADDR, data, 2, 100);
}

static void SSD1306_WriteData(uint8_t data)
{
    uint8_t tx[2] = {0x40, data};
    HAL_I2C_Master_Transmit(&hi2c1, SSD1306_I2C_ADDR, tx, 2, 100);
}

// Инициализация дисплея
void SSD1306_Init(void) {
    HAL_Delay(100);
    SSD1306_WriteCmd(0xAE); // Display OFF
    SSD1306_WriteCmd(0xD5); // Set osc frequency
    SSD1306_WriteCmd(0x80);
    SSD1306_WriteCmd(0xA8); // Set multiplex ratio
    SSD1306_WriteCmd(0x1F); // 32 lines
    SSD1306_WriteCmd(0xD3); // Set display offset
    SSD1306_WriteCmd(0x00);
    SSD1306_WriteCmd(0x40); // Set start line
    SSD1306_WriteCmd(0x8D); // Charge pump
    SSD1306_WriteCmd(0x14); // Enable charge pump
    SSD1306_WriteCmd(0x20); // Memory mode
    SSD1306_WriteCmd(0x00); // Page addressing
    SSD1306_WriteCmd(0xA1); // Segment remap (127 to 0)
    SSD1306_WriteCmd(0xC8); // COM scan direction
    SSD1306_WriteCmd(0xDA); // COM pins
    SSD1306_WriteCmd(0x02);
    SSD1306_WriteCmd(0x81); // Contrast
    SSD1306_WriteCmd(0x7F);
    SSD1306_WriteCmd(0xD9); // Precharge
    SSD1306_WriteCmd(0xF1);
    SSD1306_WriteCmd(0xDB); // VCOM detect
    SSD1306_WriteCmd(0x40);
    SSD1306_WriteCmd(0xA4); // Resume to RAM content
    SSD1306_WriteCmd(0xA6); // Normal display (не инвертировать)
    SSD1306_WriteCmd(0x2E); // Deactivate scroll
    SSD1306_WriteCmd(0xAF); // Display ON
    SSD1306_Clear();
}

void SSD1306_Clear(void) {
    for (uint8_t page = 0; page < 4; page++) {
        SSD1306_GotoXY(0, page);
        for (uint8_t i = 0; i < 128; i++) {
            // отправить пустой байт в дисплей
            uint8_t data[2] = {0x40, 0x00};
            HAL_I2C_Master_Transmit(&hi2c1, SSD1306_I2C_ADDR, data, 2, 100);
        }
    }
}

// Установка позиции курсора (x - столбец, y - страница 0..3)
void SSD1306_GotoXY(uint8_t x, uint8_t y) {
    cursor_x = x;
    cursor_page = y;
    SSD1306_WriteCmd(0xB0 + y);
    SSD1306_WriteCmd(0x00 + (x & 0x0F));
    SSD1306_WriteCmd(0x10 + ((x >> 4) & 0x0F));
}

// Вывод строки в текущую позицию
void SSD1306_Print(const char *str) {
    while (*str) {
        SSD1306_PutChar(*str++);
    }
}

// Вывод строки в указанные координаты
void SSD1306_PrintAt(uint8_t x, uint8_t y, const char *str) {
    SSD1306_GotoXY(x, y);
    SSD1306_Print(str);
}

void SSD1306_PutChar(char ch) {
    if (ch < 32 || ch > 127) ch = 32;
    ch -= 32;

    uint8_t data[7];
    data[0] = 0x40;   // control byte: данные
    for (uint8_t i = 0; i < 6; i++) {
        data[i + 1] = Font6x8[ch][i];
    }
    HAL_I2C_Master_Transmit(&hi2c1, SSD1306_I2C_ADDR, data, 7, 100);

    cursor_x += 6;
    if (cursor_x + 6 > SSD1306_WIDTH) {
        cursor_x = 0;
        cursor_page++;
        SSD1306_GotoXY(cursor_x, cursor_page);
    }
}

void SSD1306_DrawSignal(uint8_t rssi)
{
    const uint8_t x_start = 104;
    const uint8_t page = 1;

    uint8_t level;

    /*
     * RSSI:
     * 0 / 99  -> нет сети
     * 1..6    -> 1 столбик
     * 7..12   -> 2
     * 13..18  -> 3
     * 19..24  -> 4
     * 25..31  -> 5
     */

    if (rssi == 0 || rssi == 99)
    {
        level = 0;
    }
    else
    {
        level = ((rssi - 1) / 6) + 1;

        if (level > 5)
            level = 5;
    }

    /*
     * Каждый столбик занимает 3 пикселя по ширине,
     * между столбиками один пустой пиксель.
     *
     * Высоты:
     * 1 -> 0x80
     * 2 -> 0xC0
     * 3 -> 0xE0
     * 4 -> 0xF0
     * 5 -> 0xF8
     * 6 -> 0xFC
     * 7 -> 0xFE
     * 8 -> 0xFF
     */

    static const uint8_t bar_mask[5] =
    {
        0x80,   // 1/8
        0xE0,   // 3/8
        0xF8,   // 5/8
        0xFE,   // 7/8
        0xFF    // 8/8
    };

    /* Сначала очищаем область индикатора */
    SSD1306_GotoXY(x_start, page);

    for (uint8_t i = 0; i < 24; i++)
    {
        SSD1306_WriteData(0x00);
    }

    /* Нет сети — рисуем крестик */
    if (level == 0)
    {
        SSD1306_GotoXY(x_start + 4, page);

        SSD1306_WriteData(0x81);
        SSD1306_WriteData(0x42);
        SSD1306_WriteData(0x24);
        SSD1306_WriteData(0x18);
        SSD1306_WriteData(0x18);
        SSD1306_WriteData(0x24);
        SSD1306_WriteData(0x42);
        SSD1306_WriteData(0x81);

        return;
    }

    /* Рисуем пять столбиков */
    for (uint8_t bar = 0; bar < 5; bar++)
    {
        uint8_t mask = (bar < level) ? bar_mask[bar] : 0x00;

        SSD1306_GotoXY(x_start + bar * 4, page);

        SSD1306_WriteData(mask);
        SSD1306_WriteData(mask);
        SSD1306_WriteData(mask);
    }
}

