/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
#define GSM_RX_BUFFER_SIZE  256
#define SIGNAL_PERIOD       10000
#define KEY_NONE            255
#define KEY_DELETE          10
#define KEY_CALL            11
#define KEY_WAIT_LONG       40
#define SLEEP_TIMEOUT_MS  120000  // Время до засыпания (2 минуты в миллисекундах)

extern UART_HandleTypeDef huart2; // UART для SIM800C

volatile uint8_t  gsm_rx_byte;                       // приём одного байта
volatile char     gsm_rx_buffer[GSM_RX_BUFFER_SIZE]; // накопительный буфер
volatile uint16_t gsm_rx_index = 0;                  // текущая позиция
volatile uint8_t  gsm_rx_overflow = 0;
static GSM_NetStatus net_status;

// Флаги состояния
volatile uint8_t call_incoming = 0;
volatile uint8_t call_active = 0;
volatile uint8_t call_dialing = 0;
volatile uint8_t input_phone = 0;

char input_number[16] = {0}; // Буфер для вводимого номера
int number_index = 0;        // Индекс текущей цифры

// Таблица известных операторов
static const OperatorLookup op_table[] = {
    {"Bee",       "Beeline     "},
    {"MTS",       "MTS         "},
    {"MegaFon",   "MegaFon     "},
    {"Tele2",     "Tele2       "},
    {"Sber",      "SberMobile  "},
    {"T-Bank",    "T-Space     "},    // Бывший Тинькофф Мобайл
    {"Tinkoff",   "T-Space     "},    // На случай старых SIM-карт
    {"YOTA",      "Yota        "},
    {"ROSTELE",   "Rostelecom  "}
};
#define OP_TABLE_SIZE (sizeof(op_table) / sizeof(op_table[0]))

typedef struct
{
    uint32_t last_signal;
    char caller_num[20];
    uint8_t last_key;
    uint16_t key_hold_count;
    uint8_t plus_inserted;
} AppState;

static AppState app = {
    .last_key = KEY_NONE
};

uint32_t last_activity_time = 0; // Время последнего действия
char is_sleeping = 0;        // Флаг текущего состояния модуля
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */
static void App_Init(void);
static void App_MainLoop(void);
static void App_ProcessGsmEvents(void);
static void App_InitGsm(void);
static void App_ProcessKeyboard(void);
static void App_ProcessIncomingCall(void);
static void App_ProcessIncomingCallKey(void);
static void App_ProcessActiveCall(void);
static void App_ProcessCallStatus(void);
static void App_EndCall(void);
static void App_ResetGsmBuffer(void);
static void App_SendRawGsmCommand(const char *cmd);
static void App_StartOutgoingCall(void);
static uint8_t App_PrepareCallNumber(char *out, size_t out_size);
static uint8_t App_GetClccState(const char *buffer, int *state);
static void App_RefreshSignalTimer(uint32_t now);
static void App_HandleKey(uint8_t key);
static void App_HandleZeroLongPress(uint8_t key);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void GSM_UART_Start(void) {
    gsm_rx_index = 0;
    memset((void*)gsm_rx_buffer, 0, GSM_RX_BUFFER_SIZE);
    gsm_rx_overflow = 0;
    HAL_UART_Receive_IT(&huart2, (uint8_t*)&gsm_rx_byte, 1);
}

// Колбэк: вызывается HAL'ом при приёме каждого байта
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) { // проверьте свой Instance!
        if (gsm_rx_index < GSM_RX_BUFFER_SIZE - 1) {
            gsm_rx_buffer[gsm_rx_index++] = gsm_rx_byte;
            gsm_rx_buffer[gsm_rx_index]   = '\0'; // всегда держим C-строку
        } else {
            gsm_rx_overflow = 1; // буфер полон, дальше пишем в никуда
        }
        // ВАЖНО: перезапустить приём следующего байта
        HAL_UART_Receive_IT(&huart2, (uint8_t*)&gsm_rx_byte, 1);
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        __HAL_UART_CLEAR_OREFLAG(huart);
        __HAL_UART_CLEAR_FEFLAG(huart);
        __HAL_UART_CLEAR_NEFLAG(huart);
        __HAL_UART_CLEAR_PEFLAG(huart);
        HAL_UART_Receive_IT(&huart2, (uint8_t*)&gsm_rx_byte, 1);
    }
}

/**
 * Отправляет AT-команду, ждёт ответ и ищет в нём подстроку.
 * @param cmd      команда без \r\n (например "AT" или "AT+CPIN?")
 * @param expected ожидаемая подстрока (например "OK" или "READY")
 * @param timeout  общий таймаут ожидания, мс
 * @return 1 — найдено, 0 — таймаут или не найдено
 */
uint8_t GSM_SendCommand(const char *cmd, const char *expected, uint32_t timeout) {
    uint32_t tick;

    // 1) Сброс буфера перед новой командой
    __disable_irq();
    gsm_rx_index    = 0;
    gsm_rx_overflow = 0;
    gsm_rx_buffer[0] = '\0';
    __enable_irq();

    // 2) Отправка команды
    HAL_UART_Transmit(&huart2, (uint8_t*)cmd, strlen(cmd), 100);
    HAL_UART_Transmit(&huart2, (uint8_t*)"\r\n", 2, 100);

    // 3) Ожидание ответа
    tick = HAL_GetTick();
    while ((HAL_GetTick() - tick) < timeout) {
        // Проверяем накопленный буфер
        if (gsm_rx_index > 0) {
            if (strstr((const char*)gsm_rx_buffer, expected) != NULL) {
                return 1;
            }
        }

        // Проверка на явную ошибку модуля — можно не ждать весь таймаут
        if (gsm_rx_index > 0) {
            if (strstr((const char*)gsm_rx_buffer, "ERROR") != NULL) {
                return 0;
            }
        }

        // Защита от переполнения — если буфер забился, а ответа нет
        if (gsm_rx_overflow) {
            return 0;
        }

        // Небольшая пауза, чтобы не крутить цикл вхолостую
        for (volatile uint32_t i = 0; i < 1000; i++) __NOP();
    }

    return 0;
}

uint16_t GSM_DebugCommand(const char *cmd, uint32_t timeout) {
    uint32_t tick;

    __disable_irq();
    gsm_rx_index    = 0;
    gsm_rx_overflow = 0;
    gsm_rx_buffer[0] = '\0';
    __enable_irq();

    HAL_UART_Transmit(&huart2, (uint8_t*)cmd, strlen(cmd), 100);
    HAL_UART_Transmit(&huart2, (uint8_t*)"\r\n", 2, 100);

    tick = HAL_GetTick();
    while ((HAL_GetTick() - tick) < timeout) {
        // ждём весь таймаут, прерывания копят байты
    }

    return gsm_rx_index;
}

// Периодическая проверка регистрации в сети
void GSM_CheckNetwork(void) {
    // AT+CREG? → "+CREG: 0,1" (домашняя сеть) или "+CREG: 0,5" (роуминг)
    // Ищем именно ",1" или ",5", чтобы не путать с другими цифрами
    if (GSM_SendCommand("AT+CREG?", ",1", 2000) ||
        GSM_SendCommand("AT+CREG?", ",5", 2000)) {
        SSD1306_PrintAt(0, 3, "NET:  OK  ");
    } else {
        SSD1306_PrintAt(0, 3, "NET:  NO  ");
        // Можно попробовать перезапустить регистрацию
        GSM_SendCommand("AT+CFUN=0", "OK", 3000);
        HAL_Delay(1000);
        GSM_SendCommand("AT+CFUN=1", "OK", 3000);
    }
}

// (опционально) уровень сигнала
void GSM_CheckSignal(void) {
	if(net_status.rssi == 50){
	    	SSD1306_Clear();
	    }

	GSM_UpdateNetStatus();
	    /* Название оператора */
	SSD1306_PrintAt(0, 1, net_status.operator);

	    /* Графический индикатор сигнала */
	SSD1306_DrawSignal(net_status.rssi);

	    /* time */
	SSD1306_PrintAt(1, 3, net_status.time);
}

// Находит +CLIP: в буфере и извлекает номер
// Возвращает 1 если номер найден, 0 если нет
uint8_t GSM_GetCallerNumber(char *out, uint8_t max_len) {
    // 1. Ищем начало маркера
    char *p = strstr((const char*)gsm_rx_buffer, "+CLIP:");
    if (p == NULL) return 0;

    // 2. Ищем ПЕРВУЮ открывающую кавычку после "+CLIP:"
    p = strchr(p, '"');
    if (p == NULL) return 0;
    p++; // Шагаем внутрь кавычек (на первый символ номера)

    // 3. Ищем ЗАКРЫВАЮЩУЮ кавычку
    char *end = strchr(p, '"');
    if (end == NULL) return 0;

    // 4. Безопасное копирование
    uint8_t len = end - p;
    if (len >= max_len) {
        len = max_len - 1;
    }

    strncpy(out, p, len);
    out[len] = '\0';

    return 1;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
    net_status.rssi = 50; // признак, что в структуре еще нет данных

    App_Init();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    last_activity_time = HAL_GetTick();
    while (1)
    {
    	/*
    	if (!is_sleeping) {
    	   // Проверяем, прошло ли 2 минуты с момента последней активности
    	   if ((HAL_GetTick() - last_activity_time) >= SLEEP_TIMEOUT_MS) {
    	      // Время истекло — отправляем модуль в сон
    	      HAL_GPIO_WritePin(DTR_GPIO_Port, DTR_Pin, GPIO_PIN_SET); // DTR = 1
    	      is_sleeping = 1;
    	      SSD1306_PrintAt(1, 4, "SLEEP...");
    	   }
    	 }
    	 */

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
        App_MainLoop();
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_4;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00B07CB4;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(PWX_GPIO_Port, PWX_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, DTR_Pin|Col0_Pin|Col1_Pin|Col2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PWX_Pin */
  GPIO_InitStruct.Pin = PWX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(PWX_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DTR_Pin Col0_Pin Col1_Pin Col2_Pin */
  GPIO_InitStruct.Pin = DTR_Pin|Col0_Pin|Col1_Pin|Col2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Row0_Pin Row1_Pin Row2_Pin Row3_Pin */
  GPIO_InitStruct.Pin = Row0_Pin|Row1_Pin|Row2_Pin|Row3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* =========================== Application =========================== */

static void App_Init(void)
{
    GSM_UART_Start();
    App_InitGsm();
    app.last_signal = HAL_GetTick();

    GSM_SendCommand("AT+CLIP=1", "OK", 1000);
    GSM_SendCommand("AT+COLP=1", "OK", 1000);
    GSM_SendCommand("AT+CALM=0", "OK", 1000);
    GSM_SendCommand("AT+CALS=3", "OK", 1000);
    GSM_SendCommand("AT+CRSL=100", "OK", 1000);
    GSM_SendCommand("AT+CLCC=1", "OK", 1000);
    GSM_SendCommand("AT+CLTS=1", "OK", 1000);
    GSM_SendCommand("AT&W", "OK", 1000);
    GSM_SendCommand("AT+CSCLK=1", "OK", 1000); // Разрешаем модулю спать при DTR=1
}

static void App_InitGsm(void)
{
    SSD1306_Init();
    SSD1306_Clear();
    SSD1306_PrintAt(7, 2, "Viktand Phone");

    HAL_GPIO_WritePin(PWX_GPIO_Port, PWX_Pin, GPIO_PIN_RESET);
    HAL_Delay(1500);
    HAL_GPIO_WritePin(PWX_GPIO_Port, PWX_Pin, GPIO_PIN_SET);
    HAL_Delay(5000);

    SSD1306_Clear();
    SSD1306_PrintAt(0, 0, "GSM Init...");

    for (uint8_t i = 0; i < 5; i++)
    {
        GSM_SendCommand("AT", "OK", 300);
        HAL_Delay(100);
    }

    SSD1306_PrintAt(0, 1,
                    GSM_SendCommand("AT", "OK", 2000) ? "AT:   OK" : "AT:   FAIL");
    HAL_Delay(500);

    SSD1306_PrintAt(0, 2,
                    GSM_SendCommand("AT+CPIN?", "READY", 2000) ? "SIM:  READY" : "SIM:  ERROR");
    HAL_Delay(500);

    SSD1306_PrintAt(0, 3,
                    (GSM_SendCommand("AT+CREG?", "1", 3000) ||
                     GSM_SendCommand("AT+CREG?", "5", 3000)) ? "NET:  OK" : "NET:  NO");
    HAL_Delay(500);

    GSM_CheckSignal();
}

static void App_MainLoop(void)
{
    const uint32_t now = HAL_GetTick();

    App_RefreshSignalTimer(now);
    App_ProcessKeyboard();
    App_ProcessGsmEvents();
    if(is_sleeping) return;
    App_ProcessIncomingCallKey();
    App_ProcessActiveCall();
}

static void App_ProcessGsmEvents(void)
{
    /* Сначала разбираем состояние звонка, затем обработчик входящего RING
       может безопасно очистить уже обработанный RX-буфер. */
    App_ProcessCallStatus();
    App_ProcessIncomingCall();
}

static void App_RefreshSignalTimer(uint32_t now)
{
    if ((now - app.last_signal) < SIGNAL_PERIOD)
        return;

    app.last_signal = now;

    if (!call_active && !call_dialing && !input_phone)
        GSM_CheckSignal();
}

static void App_ProcessKeyboard(void)
{
    if (call_active || call_dialing)
        return;

    const uint8_t key = GetKey();

    /* Сбрасываем состояние удержания только после отпускания 0
       или при нажатии любой другой клавиши.
       При удержании 0 счетчик должен продолжать расти. */
    if (key != 0)
    {
        app.key_hold_count = 0;
        app.plus_inserted = 0;
    }

    if (app.last_key != key)
    {
        app.last_key = key;
        App_HandleKey(key);
    }
    else
    {
        App_HandleZeroLongPress(key);
    }
}

static void App_HandleKey(uint8_t key)
{
    if (key < 10 && number_index < (sizeof(input_number) - 1))
    {
        if (!(key == 0 && app.plus_inserted))
        {
            if (!input_phone)
                SSD1306_Clear();

            input_phone = 1;
            input_number[number_index++] = key + '0';
            input_number[number_index] = '\0';
            SSD1306_PrintAt(0, 0, input_number);
        }
    }

    if (key == KEY_DELETE)
    {
        if (number_index > 0)
        {
            number_index--;
            input_number[number_index] = ' ';
            input_number[number_index + 1] = '\0';
            SSD1306_PrintAt(0, 0, input_number);
            input_number[number_index] = '\0';

            if (number_index == 0)
                input_phone = 0;
        }
    }

    if (key == KEY_CALL)
        App_StartOutgoingCall();
}

static void App_HandleZeroLongPress(uint8_t key)
{
    if (key == 0 &&
        number_index == 1 &&
        input_number[0] == '0' &&
        !app.plus_inserted)
    {
        if (++app.key_hold_count == KEY_WAIT_LONG)
        {
            app.key_hold_count = 0;
            app.plus_inserted = 1;
            input_number[0] = '+';
            SSD1306_PrintAt(0, 0, input_number);
        }
    }
}

static void App_EndCall(void)
{
    call_active = 0;
    call_dialing = 0;
    call_incoming = 0;

    /* Завершённый звонок заканчивает и текущий набор номера. */
    input_phone = 0;
    number_index = 0;
    input_number[0] = '\0';

    app.last_key = KEY_NONE;
    app.key_hold_count = 0;
    app.plus_inserted = 0;

    SSD1306_Clear();
    SSD1306_PrintAt(0, 0, "CALL: ENDED");

    /* Немного показываем сообщение, затем возвращаем обычный экран. */
    HAL_Delay(1000);
    GSM_CheckSignal();
    app.last_signal = HAL_GetTick();
}

static void App_ProcessIncomingCall(void)
{
    if (gsm_rx_index == 0)
        return;

    if (strstr((const char *)gsm_rx_buffer, "RING") != NULL && !call_incoming)
    {
        call_incoming = 1;
        SSD1306_Clear();
        SSD1306_PrintAt(0, 0, "CALL: INCOMING");
    }

    if (GSM_GetCallerNumber(app.caller_num, sizeof(app.caller_num)))
        SSD1306_PrintAt(0, 1, app.caller_num);

    if (strchr((const char *)gsm_rx_buffer, '\n') != NULL)
        App_ResetGsmBuffer();
}

static void App_ProcessIncomingCallKey(void)
{
    if (!call_incoming)
        return;

    const uint8_t key = GetKey();
    if (key == KEY_NONE)
        return;

    if (key == KEY_DELETE)
    {
        GSM_SendCommand("ATH", "OK", 1000);
        App_EndCall();
        return;
    }

    if (!call_active && !call_dialing)
    {
        if (GSM_SendCommand("ATA", "OK", 5000))
        {
            call_active = 1;
            call_incoming = 0;
            SSD1306_PrintAt(1, 4, "CALL: ACTIVE  ");
        }
    }
}

static void App_ProcessActiveCall(void)
{
    if (!call_active)
        return;

    if (GetKey() == KEY_DELETE)
    {
        GSM_SendCommand("ATH", "OK", 1000);
        App_EndCall();
    }
}

static uint8_t App_GetClccState(const char *buffer, int *state)
{
    const char *p = strstr(buffer, "+CLCC:");
    if (p == NULL)
        return 0;

    /* +CLCC: <idx>,<dir>,<stat>,<mode>,<mpty> ... */
    p = strchr(p, ',');
    if (p == NULL)
        return 0;
    p++;

    p = strchr(p, ',');
    if (p == NULL)
        return 0;
    p++;

    *state = atoi(p);
    return 1;
}

static void App_ProcessCallStatus(void)
{
    if (gsm_rx_index == 0)
        return;

    const char *buffer = (const char *)gsm_rx_buffer;

    /* Модем сообщает о завершении вызова независимо от его причины. */
    if (strstr(buffer, "NO CARRIER") != NULL ||
        strstr(buffer, "BUSY") != NULL)
    {
        App_EndCall();
        App_ResetGsmBuffer();
        return;
    }

    /* Исходящий вызов: следим за состоянием через +CLCC. */
    if (call_dialing)
    {
        int state;

        if (App_GetClccState(buffer, &state))
        {
            if (state == 0)             /* active */
            {
                call_dialing = 0;
                call_active = 1;
                SSD1306_PrintAt(0, 4, "CALL: ACTIVE  ");
                App_ResetGsmBuffer();
                return;
            }

            if (state == 6)             /* disconnected */
            {
                App_EndCall();
                App_ResetGsmBuffer();
                return;
            }
        }
    }

    /* Уже установленный вызов: статус 6 означает разъединение. */
    if (call_active)
    {
        int state;

        if (App_GetClccState(buffer, &state) && state == 6)
        {
            App_EndCall();
            App_ResetGsmBuffer();
        }
    }
}

static void App_ResetGsmBuffer(void)
{
    __disable_irq();
    memset((void *)gsm_rx_buffer, 0, sizeof(gsm_rx_buffer));
    gsm_rx_index = 0;
    __enable_irq();
}


void GSM_UpdateNetStatus(void) {
    char *ptr;

    // 1. Запрашиваем уровень сигнала
    if (GSM_SendCommand("AT+CSQ", "+CSQ:", 1000)) {
        // Ищем начало ответа в буфере
        ptr = strstr((const char*)gsm_rx_buffer, "+CSQ: ");
        if (ptr != NULL) {
            // Читаем число после "+CSQ: "
            net_status.rssi = atoi(ptr + 6);
        }
    } else {
        net_status.rssi = 99; // Нет сигнала
    }

    // 2. Запрашиваем имя оператора по таблице совпадений
    if (GSM_SendCommand("AT+COPS?", "+COPS:", 1500)) {

        // ЖДЕМ 150 миллисекунд, чтобы SIM800C успел дослать хвост строки с именем оператора!
        HAL_Delay(150);

        char clean_buf[GSM_RX_BUFFER_SIZE] = {0};
        uint16_t clean_len = 0;

        // 1. Безопасно копируем буфер побайтово
        __disable_irq();
        clean_len = gsm_rx_index;
        if (clean_len >= GSM_RX_BUFFER_SIZE) clean_len = GSM_RX_BUFFER_SIZE - 1;
        for (uint16_t i = 0; i < clean_len; i++) {
            clean_buf[i] = gsm_rx_buffer[i];
        }
        clean_buf[clean_len] = '\0';
        __enable_irq();

        // 2. Ищем совпадения по нашей таблице
        uint8_t found = 0;
        for (uint8_t i = 0; i < OP_TABLE_SIZE; i++) {
            if (strstr(clean_buf, op_table[i].pattern) != NULL) {
                strncpy(net_status.operator, op_table[i].friendly_name, 16);
                net_status.operator[15] = '\0';
                found = 1;
                break;
            }
        }

        // 3. Если оператор не найден в таблице
        if (!found) {
            if (strstr(clean_buf, "\"") == NULL) { // Если кавычек вообще нет в ответе
                strcpy(net_status.operator, "No Network");
            } else {
                strcpy(net_status.operator, "Unknown Net");
            }
        }
    } else {
        strcpy(net_status.operator, "No UART Resp");
    }

    // 4. Запрашиваем текущее время
    if (GSM_SendCommand("AT+CCLK?", "OK", 1000)) {
        // Ищем начало ответа в буфере
        char *ptr = strstr((const char*)gsm_rx_buffer, "+CCLK:");
        if (ptr != NULL) {
            int year, month, day, hour, minute, second;

            // Находим первую кавычку после +CCLK:
            char *time_str = strchr(ptr, '"');
            if (time_str != NULL) {
                // Разбираем строку формата "YY/MM/DD,HH:MM:SS"
                // time_str + 1 сдвигает указатель за кавычку
                if (sscanf(time_str + 1, "%d/%d/%d,%d:%d:%d", &year, &month, &day, &hour, &minute, &second) == 6) {
                    // Собираем в нужном формате: "ДД.ММ   ЧЧ:ММ"
                    // %02d гарантирует, что числа вроде 9 будут выведены как 09
                    sprintf(net_status.time, "%02d.%02d           %02d:%02d", day, month, hour, minute);
                } else {
                    strcpy(net_status.time, "00.00   00:00"); // Ошибка парсинга строки
                }
            }
        }
    } else {
        strcpy(net_status.time, "--"); // Нет сигнала (сохраняем как строку)
    }

}

// Включить клавиатуру. Ну просто сбросить линии сканирования
void KeyboardOn(){
	HAL_GPIO_WritePin(Col0_GPIO_Port, Col0_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(Col1_GPIO_Port, Col1_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(Col2_GPIO_Port, Col2_Pin, GPIO_PIN_RESET);
}



uint8_t ReadRow(){
	// Читаем порты PA9...PA12 и сдвигаем их в младшие 4 бита результата
	// Теперь в pins_state:
	// бит 0 -> PA9
	// бит 1 -> PA10
	// бит 2 -> PA11
	// бит 3 -> PA12
	uint8_t pins_state = (uint8_t)((GPIOA->IDR >> 9) & 0x0F);
	if (pins_state == 0 || (pins_state & (pins_state - 1)) != 0) {
	     return 0;
	}
	return pins_state;
}

// Проверить нажатые клавиши
// 255 - нет нажатых
// 0..9 - цифры
// 10 - слева от 0
// 11 - справа от 0
uint8_t GetKeyRaw(void){
	uint8_t pins = 0;
	HAL_GPIO_WritePin(Col0_GPIO_Port, Col0_Pin, GPIO_PIN_SET);
	pins = ReadRow();
	HAL_GPIO_WritePin(Col0_GPIO_Port, Col0_Pin, GPIO_PIN_RESET);
	if(pins > 0){
		if(pins == 1) return 1;
		if(pins == 2) return 4;
		if(pins == 4) return 7;
		if(pins == 8) return 10;
	}

	HAL_GPIO_WritePin(Col1_GPIO_Port, Col1_Pin, GPIO_PIN_SET);
	pins = ReadRow();
	HAL_GPIO_WritePin(Col1_GPIO_Port, Col1_Pin, GPIO_PIN_RESET);
	if(pins > 0){
		if(pins == 1) return 2;
		if(pins == 2) return 5;
		if(pins == 4) return 8;
		if(pins == 8) return 0;
	}

	HAL_GPIO_WritePin(Col2_GPIO_Port, Col2_Pin, GPIO_PIN_SET);
	pins = ReadRow();
	HAL_GPIO_WritePin(Col2_GPIO_Port, Col2_Pin, GPIO_PIN_RESET);
	if(pins > 0){
		if(pins == 1) return 3;
		if(pins == 2) return 6;
		if(pins == 4) return 9;
		if(pins == 8) return 11;
	}
	return 255;
}

uint8_t GetKey(void){
	uint8_t key1 = GetKeyRaw();
	HAL_Delay(20);
	uint8_t key2 = GetKeyRaw();
	if(key1 == key2) return key1;
	return 255;
}

static void App_SendRawGsmCommand(const char *cmd)
{
    App_ResetGsmBuffer();

    HAL_UART_Transmit(&huart2,
                      (uint8_t *)cmd,
                      strlen(cmd),
                      100);
}

static uint8_t App_PrepareCallNumber(char *out, size_t out_size)
{
    if (number_index <= 0)
        return 0;

    /* Номер начинается с 8: ожидаем 11 цифр и переводим в +7. */
    if (input_number[0] == '8')
    {
        if (number_index != 11)
        {
            SSD1306_Clear();
            SSD1306_PrintAt(0, 0, "ERR: BAD LENGTH");
            HAL_Delay(1500);
            SSD1306_Clear();
            SSD1306_PrintAt(0, 0, input_number);
            return 0;
        }

        snprintf(out, out_size, "+7%s", &input_number[1]);
        return 1;
    }

    /* Номер уже введён в формате +7XXXXXXXXXX. */
    if (input_number[0] == '+' && input_number[1] == '7')
    {
        if (number_index != 12)
        {
            SSD1306_Clear();
            SSD1306_PrintAt(0, 0, "ERR: BAD LENGTH");
            HAL_Delay(1500);
            SSD1306_Clear();
            SSD1306_PrintAt(0, 0, input_number);
            return 0;
        }
    }

    strncpy(out, input_number, out_size - 1);
    out[out_size - 1] = '\0';
    return 1;
}

static void App_StartOutgoingCall(void)
{
    char final_number[20];
    char cmd_buffer[40];

    if (!App_PrepareCallNumber(final_number, sizeof(final_number)))
        return;

    snprintf(cmd_buffer, sizeof(cmd_buffer), "ATD%s;\r\n", final_number);

    SSD1306_Clear();
    SSD1306_PrintAt(0, 0, "CALLING...");
    SSD1306_PrintAt(0, 1, final_number);

    /*
     * ATD запускает асинхронный вызов.
     * Здесь нельзя ждать OK через GSM_SendCommand(), потому что
     * дальнейшее состояние вызова приходит отдельными сообщениями.
     */
    App_SendRawGsmCommand(cmd_buffer);

    call_incoming = 0;
    call_active = 0;
    call_dialing = 1;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
